def main():
    print("Multiplication table")
    print("-------------------")
    for i in range(1, 11):
        for j in range(1, 11):
            print(i*j, end="\t")
        print()


main()
